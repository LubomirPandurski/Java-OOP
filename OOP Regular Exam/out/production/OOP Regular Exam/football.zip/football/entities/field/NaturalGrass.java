package football.entities.field;

public class NaturalGrass extends BaseField{

    private static final int CAPACITY = 250;

    public NaturalGrass(String name, int capacity) {
        super(name, CAPACITY);
    }
}

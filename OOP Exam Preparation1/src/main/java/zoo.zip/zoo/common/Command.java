package zoo.common;
public enum Command {
    AddArea,
    BuyFood,
    FoodForArea,
    AddAnimal,
    FeedAnimal,
    CalculateKg,
    GetStatistics,
    Exit
}

